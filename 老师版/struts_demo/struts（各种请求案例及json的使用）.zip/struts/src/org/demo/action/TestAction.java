package org.demo.action;

import java.util.List;

import org.demo.dao.UserDao;
import org.demo.entity.Users;

public class TestAction {

	private Users user;

	private String message;

	private List<Users> list;

	public void setUser(Users user) {
		this.user = user;
	}

	public Users getUser() {
		return user;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<Users> getList() {
		return list;
	}

	public void setList(List<Users> list) {
		this.list = list;
	}

	// 转发
	public String forward() {
		System.out.println(user.getUserName());
		System.out.println(user.getAge());
		return "forward";
	}

	// 重定向
	public String redirect() {
		System.out.println(user.getUserName());
		System.out.println(user.getAge());
		return "redirect";
	}

	// 返回json
	public String json() {
		message = "success";
		return "json";
	}

	public String json2() {
		UserDao dao = new UserDao();
		list = dao.findUsers();
		return "json2";
	}

}
