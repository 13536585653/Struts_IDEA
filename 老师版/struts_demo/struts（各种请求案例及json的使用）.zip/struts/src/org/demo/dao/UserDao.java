package org.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.demo.entity.Address;
import org.demo.entity.Users;

public class UserDao {

	public List<Users> findUsers(){
		List<Users> list = new ArrayList<Users>();
		Users u1 = new Users();
		u1.setUserName("user1");
		u1.setAge(19);
		
		Users u2 = new Users();
		u2.setUserName("user2");
		u2.setAge(20);
		
		Address addr1 = new Address();
		addr1.setAddrName("珠海");
		
		Address addr2 = new Address();
		addr2.setAddrName("深圳");
		
		u1.getAddress().add(addr1);
		u1.getAddress().add(addr2);
		u2.getAddress().add(addr1);
		u2.getAddress().add(addr2);

		list.add(u1);
		list.add(u2);
		
		return list;
	}
}
