package org.demo.entity;

import java.util.HashSet;
import java.util.Set;

public class Users {

	private String userName;
	private int age;
	Set<Address> address = new HashSet<Address>();

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Set<Address> getAddress() {
		return address;
	}

	public void setAddress(Set<Address> address) {
		this.address = address;
	}

}
