package org.ch12.action;

import com.opensymphony.xwork2.ActionSupport;
import org.ch12.entity.Users;

/**
 * Created by wangl on 2017/2/14.
 * 使用令牌必须继承ActionSupport
 */
public class UserAction extends ActionSupport{

    private Users user;

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public String add(){
        System.out.println(user.getUserName());
        return "success";
    }
}
