package org.ch12.entity;

/**
 * Created by wangl on 2017/2/14.
 */
public class Users {

    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
