package org.ch08.entity;

/**
 * Created by wangl on 2017/2/8.
 */
public class Users {

    private String userName;
    private String password;
    private Card card;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Card getCard() {
        return card;
    }

    public void setCard(Card card) {
        this.card = card;
    }
}
