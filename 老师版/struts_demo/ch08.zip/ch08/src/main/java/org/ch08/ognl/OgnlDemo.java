package org.ch08.ognl;

import ognl.Ognl;
import ognl.OgnlException;
import org.ch08.entity.Card;
import org.ch08.entity.Users;

/**
 * Created by wangl on 2017/2/8.
 */
public class OgnlDemo {

    public static void main(String[] args) throws Exception {
        Users user = new Users();
        user.setUserName("zing");
        user.setPassword("123");
        Card card = new Card();
        card.setCardNum("4409021980000095");
        user.setCard(card);

        System.out.println("----传统方式----");
        System.out.println(user.getUserName());
        System.out.println(user.getCard().getCardNum());

        System.out.println("----OGNL访问方式----");
        String userName = (String)Ognl.getValue("userName", user);
        System.out.println(userName);
        String cardNum = (String)Ognl.getValue("card.cardNum",user);
        System.out.println(cardNum);
    }
}
