package org.ch08.action;

import com.opensymphony.xwork2.ActionContext;
import org.ch08.entity.Users;

/**
 * Created by wangl on 2017/2/8.
 */
public class UserAction {

    private Users user;

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public String login(){
        Users u1 = new Users();
        u1.setUserName("user1");
        //将u1放入请求作用域
        ActionContext.getContext().put("u1",u1);
        return "success";
    }
}
