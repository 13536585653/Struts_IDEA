package org.ch08.vs;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.util.CompoundRoot;
import com.opensymphony.xwork2.util.ValueStack;
import org.ch08.entity.Card;
import org.ch08.entity.Users;

import java.util.Map;

/**
 * Created by wangl on 2017/2/8.
 */
public class ValueStackDemoAction {

    private Users user;

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public String test(){
        //获取请求对象
        Map<String, Object> request = (Map<String, Object>)ActionContext.getContext().get("request");
        //获取会话对象
        Map<String, Object> session = ActionContext.getContext().getSession();
        //获取上下文对象
        Map<String, Object> application = ActionContext.getContext().getApplication();
        //获取值栈,默认struts将ValueStack设置为OgnlContext的根(Root)
        ValueStack vs = ActionContext.getContext().getValueStack();
        //struts的值栈是基于List的数据结构实现的，当创建一个Action实例的时候
        //struts就会将这个action实例放入到值栈的栈顶
        //值栈中最关键的一个对象就是CompoundRoot，它是整个值栈的核心，
        //CompoundRoot就是对Ognl的真正封装，并且这个CompoundRoot是一个集合结构
        //它是实现了List接口的一种数据结构。
        //（重点：当struts创建了一个action实例的时候，就会将这个实例放入到这个root集合中）
        CompoundRoot root = vs.getRoot();
        //可以遍历这个集合查看值栈中的所有元素
        for (Object obj : root) {
            System.out.println(obj);
        }
        return "success";
    }

    public String index2(){
        Users u1 = new Users();
        u1.setUserName("user1");
        u1.setPassword("123");

        //SStruts默认会将整个Action实例放入值栈，
        // 我们也可以手动将一些其他数据放入到值栈中
        ValueStack vs = ActionContext.getContext().getValueStack();
        //进行压栈操作，其实就是将数据放入list集合中，并设置为栈顶元素
        vs.push(u1);
        //弹栈操作，就是将栈顶的元素进行移除
        //vs.pop();
        for (Object obj: vs.getRoot()) {
            System.out.println(obj);
        }
        return "success";
    }

    public String index3(){
        Users u1 = new Users();
        u1.setUserName("user1");
        u1.setPassword("123");
        Card card = new Card();
        card.setCardNum("44090219850");
        u1.setCard(card);

        //将u1存入ActionContext中
        //这样操作其实是将u1对象保存在了两个地方
        //一个是ActionContext对象的map中。
        //然后还会存储一份在request请求作用域
        ActionContext.getContext().put("u1", u1);

        //将u1对象只存放在请求作用域
        Map<String, Object> request = (Map<String, Object>)ActionContext.getContext().get("request");
        request.put("u1", u1);

        //将u1对象存储在会话作用域
        Map<String, Object> session = ActionContext.getContext().getSession();
        session.put("u1", u1);

        //将u1对象存放在上下文作用域
        Map<String, Object> application = ActionContext.getContext().getApplication();
        application.put("u1", u1);

        //将u1对象放入到值栈中
        ValueStack vs = ActionContext.getContext().getValueStack();
        vs.push(u1);

        return "success";
    }
}
