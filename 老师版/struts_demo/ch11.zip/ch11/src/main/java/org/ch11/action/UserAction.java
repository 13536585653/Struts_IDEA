package org.ch11.action;

import com.opensymphony.xwork2.ActionSupport;
import org.ch11.entity.Users;

/**
 * Created by wangl on 2017/2/13.
 * 执行验证必须继承ActionSupport
 * 可以重写validate方法，也可以自定义validateXxx的方法。
 * 两者的区别在于：validate方法会在执行任何action方法之前执行
 * 而validateXxx方法是针对某个action方法调用之前执行,
 * Xxx就是action的方法名,将首字母变为大写
 * 如果这两个校验方法同时存在，那么先执行validateXxx方法，
 * 最后再执行validate方法
 */
public class UserAction extends ActionSupport {

    private Users user;

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    //重写父类的validate方法
    @Override
    public void validate(){
        System.out.println("执行validate方法进行验证");
    }

    //自定义validateXxx方法
    public void validateReg(){
        System.out.println("执行validateReg方法进行校验");
        if(user!=null && "wangli".equals(user.getUserName())){
            //手动添加错误信息
            addFieldError("user.userName", "用户已存在");
        }
    }

    public String reg(){
        System.out.println("执行注册逻辑...");
        return SUCCESS;
    }
}
