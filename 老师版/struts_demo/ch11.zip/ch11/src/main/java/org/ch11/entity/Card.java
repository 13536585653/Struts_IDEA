package org.ch11.entity;

/**
 * Created by wangl on 2017/2/13.
 */
public class Card {

    private String cardNum;

    public String getCardNum() {
        return cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }
}
