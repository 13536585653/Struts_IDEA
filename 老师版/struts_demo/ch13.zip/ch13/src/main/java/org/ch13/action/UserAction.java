package org.ch13.action;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;
import org.ch13.entity.Users;
import org.ch13.exception.UserNotFoundException;

/**
 * Created by wangl on 2017/3/29.
 */
public class UserAction {

    private Users user;

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public String login(){
        if("wangl".equals(user.getUserName()) && "123".equals(user.getPassword())){
            user.setAge(19);
            return "success";
        }
        throw new UserNotFoundException("用户名或密码错误");
    }
}
